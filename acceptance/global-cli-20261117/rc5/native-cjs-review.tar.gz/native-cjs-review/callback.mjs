import fs from 'node:fs';import path from 'node:path';
const variant=process.argv[2]||'percall-owner';const loader=await import('./fresh-'+variant+'.mjs');const root=path.join(import.meta.dirname,'callback-'+variant);fs.mkdirSync(root,{recursive:true});const entry=path.join(root,'entry.mjs');
fs.writeFileSync(entry,"import item from './bridge.cjs';export default item;");
fs.writeFileSync(path.join(root,'bridge.cjs'),`const item=module.require('./value.cjs');module.exports={eager:item.value,read:()=>module.require('./value.cjs').value,self:module};`);
fs.writeFileSync(path.join(root,'value.cjs'),'module.exports={value:1,self:module};');
const old=(await loader.importFreshArtifact(entry)).default;globalThis.oldCallback=()=>old.read();
fs.writeFileSync(path.join(root,'value.cjs'),'module.exports={value:999,self:module};if(!globalThis.insideCallback){globalThis.insideCallback=true;globalThis.observedOldDuringNew=globalThis.oldCallback();globalThis.insideCallback=false;}');
const current=(await loader.importFreshArtifact(entry)).default;
console.log(JSON.stringify({variant,oldEager:old.eager,newEager:current.eager,oldDuringNew:globalThis.observedOldDuringNew,oldAfter:old.read(),newAfter:current.read(),events:loader.probeEvents}));
